// Teachable Machine and ml5.js
// Intro to ML for the Arts, IMA Fall 2020
// https://github.com/ml5js/Intro-ML-Arts-IMA-F20

// Copyright (c) 2019 ml5
//
// This software is released under the MIT License.
// https://opensource.org/licenses/MIT

// Classifier Variable
let classifier;
let spriteSheet;
let spriteData;

//constants
let iconSize = 81;
let sprSize = 320;
let frmRt = 15; //framerate

//arrays
let icons = [];
let iconImg = [];
let iconImgBW = [];
let elements = ['Water', 'Earth', 'Fire', 'Air'];
let textArr = [];
let aniArr= [];

// Model URL
const imageModelURL = 'https://teachablemachine.withgoogle.com/models/XOsAJst__/';

// Video
let video;
let flippedVideo;

// To store the classification
let label = "";


// Load the model & other files
function preload() {
  // eslint-disable-next-line prefer-template
  classifier = ml5.imageClassifier(imageModelURL + 'model.json');
  //loading icons
  iconImg[0] = loadImage('iconImages/waterHand.png');
  iconImg[1] = loadImage('iconImages/earthHand.png');
  iconImg[2] = loadImage('iconImages/fireHand.png');
  iconImg[3] = loadImage('iconImages/airHand.png');
  //loading black & white icons
  iconImgBW[0] = loadImage('iconImagesBW/waterHandBW.png');
  iconImgBW[1] = loadImage('iconImagesBW/earthHandBW.png');
  iconImgBW[2] = loadImage('iconImagesBW/fireHandBW.png');
  iconImgBW[3] = loadImage('iconImagesBW/airHandBW.png');
  table = loadImage('iconImagesBW/table.png');
  //textArray
  textArr[0] = "Slay the monster by guessing its shield's element! Press ENTER for instructions";
  textArr[1] = "Make one of the four elementary hand signs described on the right. Once your element is ready, press ENTER";
  textArr[2] = "PRESS ENTER";
  textArr[3] = "YOU WIN";
  textArr[4] = "YOU LOSE";
  textArr[5] = "THE FIEND USED A SHIELD, IT'S A DRAW";
  //Monster & animations
  monsterSpr = loadImage('animations/charSpr.png');
  aniArr[0] = loadImage('animations/waterAni.png');
  aniArr[1] = loadImage('animations/earthAni.png');
  aniArr[2] = loadImage('animations/fireAni.png');
  aniArr[3] = loadImage('animations/airAni.png');
}


class Icon {
  constructor(index) {
    this.index = index;
    this.img = iconImg[index];
    this.imgBW = iconImgBW[index];
    this.element = elements[index];
    this.x = width - iconSize * (1 + index % 2) - 10;
    this.y = video.height + iconSize * math.floor(index / 2) + 10 * (1 + math.floor(index / 2));
  }

  display() {
    if (label == this.element && monsterObj.state != "animation") {
      image(this.img, this.x, this.y, iconSize, iconSize);
    } else {
      image(this.imgBW, this.x, this.y, iconSize, iconSize);
    }
  }
}

class Monster {
  constructor(x, y) {
    this.x = x; //this isn't the x position but the border of the   canvas on which the monster is drawn
    this.y = y;
    this.state = "instructions";
    this.elementMstr = "???";
    this.elementPlyr = "";
    this.result = "";
    this.txt = 0;
    this.frame = 0;
  }

  display() {
    //formatting
    fill(255);
    strokeWeight(3);
    stroke(0);
    textSize(32);
    textAlign(CENTER);

    if (this.state == "instructions") {
      image(monsterSpr, this.x / 8, this.y, sprSize, sprSize, 0, 0, sprSize, sprSize);

      //Draw the monster's choice
      text(this.elementMstr, (this.x / 4), height - 30);
      // Draw the player's current hand element
      text(label, (3 * this.x / 4), height - 30);
      strokeWeight(3);
      stroke(102, 51, 153);
      fill(255);
      textSize(20);
      text(textArr[this.txt], this.x/8, height - 150, 3*this.x/4, 250);
    } 
    
    else if (this.state == "playing") {
      if (this.result == "win") {
        image(monsterSpr, this.x / 8, this.y, sprSize, sprSize, this.frame*320, 0, sprSize, sprSize);
      } 
      
      else if (this.result == "loss") {
        image(monsterSpr, this.x / 8, this.y, sprSize, sprSize, this.frame*320, 0, sprSize, sprSize);
      } 
      
      else if (this.result == "draw") {
        image(monsterSpr, this.x / 8, this.y, sprSize, sprSize, this.frame*320, 0, sprSize, sprSize);
      }
      else {
        image(monsterSpr, this.x / 8, this.y, sprSize, sprSize, this.frame*320, 0, sprSize, sprSize);
      }
      
      fill(255);
      strokeWeight(3);
      stroke(0);
      textSize(32);
      textAlign(CENTER);
      //Draw the monster's choice
      text(this.elementMstr, (this.x / 4), height - 30);
      // Draw the player's current hand element
      text(label, (3 * this.x / 4), height - 30);
      fill(0);
      textSize(34);
      text(textArr[this.txt], this.x/8, height - 150, 3*this.x/4, 250);
    } 
    
    else if (this.state == "animating") {
      
      if (this.result=="draw"){
        if (this.frame <13){
          image(monsterSpr, this.x / 8, this.y, sprSize, sprSize, this.frame*320, 0, sprSize, sprSize);
          this.frame++;
        } else{
          this.frame=0;
        }
      } 
      
      else if (this.result=="win"){
        image(monsterSpr, this.x / 8, this.y, sprSize, sprSize, 0, 0, sprSize, sprSize);
        if (this.frame < aniArr[elements.indexOf(this.elementPlyr)].width/320){
          image(aniArr[elements.indexOf(this.elementPlyr)], 0, -50, 3*sprSize/2, 3*sprSize/2, this.frame*320, 0, sprSize, sprSize);
          this.frame++;
        } else{
          this.frame=0;
        }
      } 
      
      else if (this.result=="loss"){
        image(monsterSpr, this.x / 8, this.y, sprSize, sprSize, 0, 0, sprSize, sprSize);
        if (this.frame <aniArr[elements.indexOf(this.elementMstr)].width/320){
          image(aniArr[elements.indexOf(this.elementMstr)], this.x, 0, sprSize/2, sprSize/2, this.frame*320, 0, sprSize, sprSize);
          this.frame++;
        } else{
          this.frame=0;
        }
      }

      fill(255);
      strokeWeight(3);
      stroke(0);
      textSize(32);
      textAlign(CENTER);
      //Draw the monster's choice
      text(this.elementMstr, (this.x / 4), height - 30);
      // Draw the player's current hand element
      text(this.elementPlyr, (3 * this.x / 4), height - 30);
      strokeWeight(3);
      fill(0);
      textSize(36);
      text(textArr[this.txt], 0, height - 150, this.x, 250);
    }
  }

  //evaluating the duel's outcome (I could've done this in a 2D array but realized too late)
  evaluate() {
    if (this.elementMstr == this.elementPlyr) {
      this.result = "draw";
    } else if (this.elementPlyr == "Fire") {
      if (this.elementMstr != "Water") {
        this.result = "win";
      } else {
        this.result = "loss";
      }
    } else if (this.elementPlyr == "Water") {
      if (this.elementMstr != "Fire") {
        this.result = "loss";
      } else {
        this.result = "win";
      }
    } else if (this.elementPlyr == "Earth") {
      if (this.elementMstr == "Water") {
        this.result = "win";
      } else if (this.elementMstr == "Fire") {
        this.result = "loss";
      } else if (this.elementMstr == "Air") {
        this.result = "draw";
      }
    } else if (this.elementPlyr == "Air") {
      if (this.elementMstr == "Water") {
        this.result = "win";
      } else if (this.elementMstr == "Fire") {
        this.result = "loss";
      } else if (this.elementMstr == "Earth") {
        this.result = "draw";
      }
    }
    if (this.result == "win"){
      this.txt=3;
      this.scoreP++;
    } else if (this.result == "loss"){
      this.txt=4;
      this.scoreM++;
    } else if (this.result == "draw") {
      this.txt=5;
    }
  }
}

// Get a prediction for the current video frame
function classifyVideo() {
  flippedVideo = ml5.flipImage(video)
  classifier.classify(flippedVideo, gotResult);
}

// When we get a result
function gotResult(error, results) {
  // If there is an error
  if (error) {
    console.error(error);
    return;
  }
  // The results are in an array ordered by confidence.
  // console.log(results[0]);
  label = results[0].label;
  // Classifiy again!
  classifyVideo();
}

function setup() {
  createCanvas(640, 520);
  frameRate(frmRt);
  // Create the video
  video = createCapture(VIDEO);
  video.size(iconSize * 2 + 23, (iconSize * 2 + 23) * 3 / 4);
  video.hide();
  flippedVideo = ml5.flipImage(video)

  // Start classifying
  classifyVideo();

  //icon classes
  for (let i = 0; i < 4; i++) {
    icons[i] = new Icon(i);
  }

  //create monster object
  monsterObj = new Monster(width - video.width, 30);
}

function draw() {

  background(227);
  fill(0);
  // Draw the video
  image(flippedVideo, width - video.width, 0);
  //Draw the icons
  rect(width - iconSize * 2 - 18, video.height + 1, iconSize * 2 + 18, iconSize * 2 + 30);
  for (let i = 0; i < icons.length; i++) {
    icons[i].display();
  }
  monsterObj.display();
  stroke(0);
  strokeWeight(9);
  line(width - iconSize - 13, video.height + 12, width - iconSize - 13, (video.height + 1) + iconSize * 2 + 20)

  //draw the table
  image(table, width - video.width, video.height + iconSize * 2 + 29, iconSize * 2 + 24, height - 4 * iconSize - 5);
}

//interaction, enter button
function keyPressed() {
  if (keyCode === ENTER) {
    monsterObj.frame=0;
    monsterObj.txt ++;
    if (monsterObj.state == "instructions") {
      if (monsterObj.txt > 1) {
        monsterObj.state = "playing";
      }
    }

    if (monsterObj.state == "playing") {
      monsterObj.elementPlyr = label;
      monsterObj.elementMstr = elements[int(random(0,4))];
      monsterObj.evaluate(); //updating score, animating, etc
      monsterObj.state = "animating";
    } 
    
    else if (monsterObj.state=="animating") {
      monsterObj.txt=2;
      monsterObj.state="playing";
    }

    print(monsterObj.state, monsterObj.elementMstr, monsterObj.result, monsterObj.frame);
  }
}
